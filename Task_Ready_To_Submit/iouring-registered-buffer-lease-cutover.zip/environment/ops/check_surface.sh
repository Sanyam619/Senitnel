#!/usr/bin/env bash
exec /app/bin/healthctl
