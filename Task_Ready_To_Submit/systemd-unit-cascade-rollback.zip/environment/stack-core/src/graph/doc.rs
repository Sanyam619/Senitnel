//! graph helpers
