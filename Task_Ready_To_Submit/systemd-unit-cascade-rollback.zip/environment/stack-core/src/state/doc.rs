//! activation helpers
