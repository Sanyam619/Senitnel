//! merge helpers
