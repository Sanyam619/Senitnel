incomplete staging tree
